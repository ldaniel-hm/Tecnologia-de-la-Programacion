import tkinter as tk

root = tk.Tk()

tk.Button(text="Botón AA").pack(padx=20, pady=20)
tk.Button(text="Botón BB").pack(side=tk.LEFT)
tk.Button(text="Botón CC").pack(ipadx=20, ipady=20)
tk.Button(text="Botón DD").pack(expand=True, fill=tk.Y)

tk.mainloop()
