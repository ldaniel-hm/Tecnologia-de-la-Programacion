from tkinter import filedialog

fichero = filedialog.asksaveasfile(mode="w",
                                   initialdir=".",
                                   title="Guardar en un fichero",
                                   parent=None)

lineas = ["Un par\n", "de lineas\n"]
if fichero is not None:
    fichero.writelines(lineas)
    fichero.close()
