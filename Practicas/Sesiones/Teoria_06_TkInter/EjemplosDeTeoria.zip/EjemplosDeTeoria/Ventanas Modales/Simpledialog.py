# Fuente: https://runestone.academy/runestone/books/published/thinkcspy/GUIandEventDrivenProgramming/02_standard_dialog_boxes.html
#

import tkinter as tk
from tkinter import simpledialog, scrolledtext

application_window = tk.Tk()

scrolledtext.ScrolledText()

answer = simpledialog.askstring("Input", "¿Tu nombre?",
                                parent=application_window)
if answer is not None:
    print("Tu nombre es ", answer)
else:
    print("¿No tienes nombre?", answer)

answer = simpledialog.askinteger("Input", "¿Tu edad?",
                                 parent=application_window,
                                 minvalue=0, maxvalue=100)
if answer is not None:
    print("Tu edad es ", answer)
else:
    print("¿No tienes edad?", answer)

answer = simpledialog.askfloat("Input", "¿Tu sueldo?",
                               parent=application_window,
                               minvalue=0.0, maxvalue=100000.0)
if answer is not None:
    print("Tu sueldo es ", answer)
else:
    print("¿No tienes sueldo?", answer)