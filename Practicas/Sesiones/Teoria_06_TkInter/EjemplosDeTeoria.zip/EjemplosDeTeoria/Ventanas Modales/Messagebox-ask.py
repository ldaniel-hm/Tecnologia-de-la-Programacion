from tkinter import messagebox


answer = messagebox.askokcancel("Question", "Do you want to open this file?")
# False, True
answer = messagebox.askretrycancel("Question", "Do you want to try that again?")
# False, True
answer = messagebox.askyesno("Question", "Do you like Python?")
# False, True
answer = messagebox.askyesnocancel("Question", "Continue playing?")
# None, False, True
