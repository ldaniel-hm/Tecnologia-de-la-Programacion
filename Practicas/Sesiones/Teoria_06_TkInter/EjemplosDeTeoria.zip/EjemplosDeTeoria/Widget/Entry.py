import tkinter as tk

root = tk.Tk()
root.title("Probando Entry")

frame = tk.Frame(root, width=350, height=200)
frame.pack()

tk.Label(frame, text="Escribe algo:").pack(padx=10)
tk.Entry(frame).pack(padx=100, pady=30, ipadx=50, ipady=5)

root.mainloop()
