import tkinter as tk
from tkinter import IntVar

def selec():
    monitor.config(text = f"Selección: {opcion.get()}" )


root = tk.Tk()
root.config(bd=15)

opcion = IntVar() # Como StrinVar pero en entero

tk.Radiobutton(root, text="Opción 1", variable=opcion,
            value=1, command=selec).pack()
tk.Radiobutton(root, text="Opción 2", variable=opcion,
            value=2, command=selec).pack()

monitor = tk.Label(root)
monitor.pack()
root.mainloop()