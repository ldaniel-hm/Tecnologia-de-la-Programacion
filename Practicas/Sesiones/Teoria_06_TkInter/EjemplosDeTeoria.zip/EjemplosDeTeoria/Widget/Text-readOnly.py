import tkinter as tk

root = tk.Tk()
root.title("Probando Text")

frame = tk.Frame(root, width=350, height=200)
frame.pack()

text = tk.Text(frame, state='disabled')
text.config(width=30, height=10, font=("Arial", 24))
text.pack(padx=100, pady=30)
text.configure(state='normal')
text.insert('end', 'No me puedes editar')
text.configure(state='disabled')

# Opcionalmente para  state='disabled'
# text.configure(state='normal')
# text.bind("<Key>", lambda e: "break")

root.mainloop()
