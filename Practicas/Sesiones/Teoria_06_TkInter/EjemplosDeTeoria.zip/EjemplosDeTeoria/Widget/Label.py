import tkinter as tk


def label_text_pack():
    root = tk.Tk()
    root.geometry("350x200+100+100")
    root.title("Probando Label")
    frame = tk.Frame(root, width=350, height=200)
    frame.pack()
    tk.Label(frame, text="¡Hola Mundo!").pack(anchor='nw')
    tk.Label(frame, text="¡Otra etiqueta muy muy larga!").pack(anchor='center')
    tk.Label(frame, text="¡Última etiqueta!").pack(anchor='se')
    root.mainloop()


def label_text_place():
    root = tk.Tk()
    root.title("Probando Label")
    root.geometry("350x200+100+100")
    frame = tk.Frame(root, width=350, height=200)
    frame.pack()
    label = tk.Label(frame, text="Esto es una prueba")
    label.place(x=50, y=100)
    label.config(fg="yellow", bg="blue")
    label.config(font=("Verdana", 24))
    root.mainloop()


def label_imagen():
    root = tk.Tk()
    root.title("Probando Label con Imagen")
    root.geometry("350x200+100+100")
    frame = tk.Frame(root, width=350, height=200)
    frame.pack()
    mi_imagen = tk.PhotoImage(file="ldaniel.png")
    label = tk.Label(frame, image=mi_imagen)
    label.place(x=50, y=40)
    root.mainloop()


if __name__ == "__main__":
    label_imagen()
    label_text_place()
    label_text_pack()
