import tkinter as tk
from tkinter import StringVar

def muestraMedida():
    print(sistemaMedida.get())

root = tk.Tk()
root.title("Checkbutton")
root.config(bd=20)

sistemaMedida = StringVar()

tk.Checkbutton(root, text='Sistema Métrico', command=muestraMedida, variable=sistemaMedida,
                onvalue='metrico', offvalue='ingles').pack()

tk.mainloop()