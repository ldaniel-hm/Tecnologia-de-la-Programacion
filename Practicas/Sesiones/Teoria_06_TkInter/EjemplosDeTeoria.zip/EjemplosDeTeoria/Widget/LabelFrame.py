import tkinter as tk

root = tk.Tk()
root.title("Probando TextLabel")

labelframe = tk.LabelFrame(root, text="Este es un LabelFrame")
labelframe.pack(fill="both", expand="yes")

left = tk.Label(labelframe, text="Dentro del LabelFrame")
left.pack()

root.mainloop()
