import tkinter as tk

root = tk.Tk()
root.title("Probando Text")

frame = tk.Frame(root, width=350, height=200)
frame.pack()

tk.Label(frame, text="Escribe algo:").pack()
text = tk.Text(frame)
text.config(width=30, height=10, font=("Arial", 24))
text.pack(padx=100, pady=30)
root.mainloop()
