import time
import tkinter as tk
from tkinter import StringVar, simpledialog


def cambiando_entry():
    root = tk.Tk()
    root.title("Entry con StringVar")
    frame = tk.Frame(root, width=150, height=100)
    frame.pack()

    # Vinculamos el StringVar al Entry
    string_var = StringVar(value="Mensaje Inicial")
    entry = tk.Entry(frame, textvariable=string_var)
    entry.pack()

    n1 = simpledialog.askfloat("Entrada", "¿1er. Número?", parent=root)
    n2 = simpledialog.askfloat("Entrada", "¿2o. Número?", parent=root)
    string_var.set(str(n1+n2))
    entry.config(state='readonly')

    root.mainloop()


if __name__ == "__main__":
    cambiando_entry()


