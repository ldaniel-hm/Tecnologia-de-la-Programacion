import tkinter as tk

root = tk.Tk()
root.geometry("300x300+100+100")
canvas = tk.Canvas(root, width=300, height=300)
canvas.pack()
canvas.create_oval(10, 10, 250, 100, fill="green")
canvas.create_text(150, 150, text="hola", font=('Helvetica','30','bold'))
canvas.create_rectangle(20, 220, 290, 290, fill="red")
canvas.create_line(0, 0, 300, 300, width=4, fill="blue")
canvas.toW
# canvas.move(r, 20, 20)
root.mainloop()